import os
import pysam
import argparse
import errno


def main():
    parser = argparse.ArgumentParser(description="Splits BAM file into two BAM files, putting p reads into one BAM and (1-p) into the other")
    parser.add_argument('-b', '--bam-file', dest='bam_file', required=True, help='Input BAM file')
    args = parser.parse_args()

    if not os.path.isfile(args.bam_file):
        print("ERROR: BAM file does not exist!")
        exit(-1)

    bam_f = pysam.AlignmentFile(args.bam_file, "rb")
    num_reads = 0
    num_paired_reads = 0
    num_unpaired_reads = 0
    num_mate_missing = 0
    num_file1 = 0
    num_file2 = 0
    bam_iter = bam_f.fetch(until_eof=True)
    # for each read in BAM file
    for read in bam_iter:
        # sample binomial to choose which output BAM file to write to
        coin_flip = 0.23
        # if paired, get matching pair and write to output
        if read.is_paired and read.is_proper_pair:
            # if this is the first read in the pair, get second read
            if read.is_read1 and not read.mate_is_unmapped:
                bam_iter_tmp = bam_iter
                # get the read's mate
                try:
                    read2 = bam_f.mate(read)
                    if coin_flip:
                        # output1_f.write(read)
                        # output1_f.write(read2)
                        num_file1 += 2
                    else:
                        # output2_f.write(read)
                        # output2_f.write(read2)
                        num_file2 += 2
                    num_paired_reads += 2
                    num_reads += 2
                # unless the mate is unavailable for some reason
                except ValueError:
                    if coin_flip:
                        # output1_f.write(read)
                        num_file1 += 1
                    else:
                        # output2_f.write(read)
                        num_file2 += 1
                    num_mate_missing += 1
                    num_reads += 1
                    continue
                finally:
                    bam_iter = bam_iter_tmp
        # else read is not paired, just throw it into a file randomly
        else:
            if coin_flip:
                # output1_f.write(read)
                num_file1 += 1
            else:
                # output2_f.write(read)
                num_file2 += 1

            num_unpaired_reads += 1
            num_reads += 1
        if num_reads % 1000 == 0:
            print("Number of reads processed:", num_reads)
        if num_reads >= 51200:
            break
            
    bam_f.close()
    # output1_f.close()
    # output2_f.close()
    print("Total reads processed:", num_reads)
    print("Number paired reads:", num_paired_reads, "\t(" + str(100.*num_paired_reads / float(num_reads)) + "%)")
    print("Number unpaired reads:", num_unpaired_reads, "\t(" + str(100.*num_unpaired_reads / float(num_reads)) + "%)")
    print("Number paired reads missing their mate:", num_mate_missing, "\t(" + str(100.*num_mate_missing / float(num_reads)) + "%)")
    print("Number of reads in first file:", num_file1, "\t(" + str(100.*num_file1 / float(num_reads)) + "%)")
    print("Number of reads in second file:", num_file2, "\t(" + str(100.*num_file2 / float(num_reads)) + "%)")

if __name__ == "__main__":
    main()